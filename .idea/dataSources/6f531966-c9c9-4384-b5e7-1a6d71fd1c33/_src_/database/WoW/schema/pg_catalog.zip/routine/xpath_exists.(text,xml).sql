CREATE FUNCTION xpath_exists (text, xml) RETURNS boolean
	LANGUAGE sql
AS $$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
$$
