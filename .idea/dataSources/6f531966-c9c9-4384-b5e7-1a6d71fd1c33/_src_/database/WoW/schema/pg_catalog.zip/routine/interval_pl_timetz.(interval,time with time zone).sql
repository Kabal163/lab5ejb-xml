CREATE FUNCTION interval_pl_timetz (interval, time with time zone) RETURNS time with time zone
	LANGUAGE sql
AS $$
select $2 + $1
$$
