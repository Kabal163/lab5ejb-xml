CREATE FUNCTION interval_pl_timestamp (interval, timestamp without time zone) RETURNS timestamp without time zone
	LANGUAGE sql
AS $$
select $2 + $1
$$
